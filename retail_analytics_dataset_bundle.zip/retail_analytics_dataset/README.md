# Retail Business Performance & Profitability Analytics Dataset

## Important disclosure
This is a **synthetic practice dataset generated for this portfolio project**, not actual records from a real retailer. Findings must be described as findings from simulated data, not a real company.

## Files
- `retail_analytics_dataset.xlsx`: workbook with Orders, Products, Customers, Stores, Returns, and DataDictionary sheets.
- Individual CSV files for SQL/Python workflows.
- `data_dictionary.csv`: field definitions.

## Suggested business questions
1. What are total sales, profit, profit margin, and distinct order count?
2. Which categories, subcategories, and products contribute most/least profit?
3. How do sales and profit vary by month, store, region, and sales channel?
4. How do discount bands relate to profitability?
5. Which customer segments contribute to sales and profit?
6. What does return activity look like by reason, region, and time?
7. What data-quality issues exist, and how should they be handled?

## Data quality practice
The Orders table intentionally contains a small number of missing values and duplicate rows. Identify, document, and assess their impact before choosing a treatment. Do not blindly delete or fill values. Returns are at order-level; joining them directly to line-level Orders and summing sales can multiply values unless the grains are handled correctly.

## Table grain
- Orders: intended grain is one row per order line, with intentional duplicate rows for QA practice.
- Products: one row per product.
- Customers: one row per customer.
- Stores: one row per store.
- Returns: one row per return record associated with an order.

## Workflow
1. Excel: inspect schema, filters, duplicates, missing values, and baseline totals.
2. SQL: load tables, validate keys/grain, write business queries and reconciliation checks.
3. Python: use pandas for data quality, EDA, and cross-checks.
4. Power BI: create relationships, DAX measures, and an interactive dashboard.
5. GitHub: include methodology, data dictionary, queries, notebook, dashboard screenshots, limitations, and evidence-backed recommendations.

## Currency and realism
Amounts are simulated units. Do not label them INR or claim they reflect a real company unless you explicitly adapt and document the scenario.
